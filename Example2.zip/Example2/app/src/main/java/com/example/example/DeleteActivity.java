package com.example.example;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
public class DeleteActivity extends AppCompatActivity {
    Button btndisplay, btndel;
    EditText edtregno;
    ListView lststud;
    ArrayList studdata = new ArrayList();
    ArrayAdapter adpt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        btndisplay = (Button) findViewById(R.id.btndisplay);
        btndel = (Button) findViewById(R.id.btndel);
        edtregno = (EditText) findViewById(R.id.edtregno);
        lststud = (ListView) findViewById(R.id.lststud);
    }

    public void DisplayStud(View v) {
        DatabaseAccessActivity ob = new DatabaseAccessActivity(DeleteActivity.this);
        studdata = ob.DisplayRecord();
        adpt = new ArrayAdapter(this, android.R.layout.simple_list_item_1, studdata);
        lststud.setAdapter(adpt);
    }

    public void DeleteStud(View v) {
        DatabaseAccessActivity ob1 = new DatabaseAccessActivity(DeleteActivity.this);
        String regno = edtregno.getText().toString();
        ob1.DeleteRecord(regno);
        Toast.makeText(getApplicationContext(), "Record successfully deleted", Toast.LENGTH_LONG).show();
    }

    public void Menu(View view) {
        Intent myIntent = new Intent(DeleteActivity.this,MainActivity.class);
        DeleteActivity.this.startActivity(myIntent);
    }
}