package com.example.example;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import java.util.ArrayList;

public class DatabaseAccessActivity extends SQLiteOpenHelper {
    public static final String db = "studentdb";
    public static final String tab = "studenttab";
    public static final String col1 = "regno";
    public static final String col2 = "name";
    public ArrayList studdata = new ArrayList();

    public DatabaseAccessActivity(@Nullable Context context) {
        super(context, "studentdb", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create table " + tab + "(" + col1 + " text, " + col2 + " text)";
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    }
    public void Insertstud(String regno, String name) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(col1, regno);
        cv.put(col2, name);
        db.insert(tab, null, cv);
        db.close();
    }
    public ArrayList DisplayRecord() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cu = db.rawQuery("Select * from " + tab, null);
        while (cu.moveToNext()) {
            studdata.add(cu.getString(0) + "\t\t" + cu.getString(1));
        }
        return studdata;
    }
    public void DeleteRecord(String regno) {
        SQLiteDatabase db = getWritableDatabase();
        // db.execSQL("delete from "+tab+" where "+col1+" = "+regno);
        // db.close();
        db.delete(tab, col1 + " = ?", new String[]{regno});
    }
    public void UpdateRecord(String regno, String name) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("update " + tab + " SET " + col2 + " = " + "'" + name + "'" + " where " + col1 + " = " + "'" + regno + "'");
        db.close();
    }
}
