package com.example.example;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Insert(View v) {
        Intent myIntent = new Intent(MainActivity.this,InsertActivity.class);
        MainActivity.this.startActivity(myIntent);
    }

    public void Delete(View v) {
        Intent myIntent = new Intent(MainActivity.this,DeleteActivity.class);
        MainActivity.this.startActivity(myIntent);
    }

    public void Update(View v) {
        Intent myIntent = new Intent(MainActivity.this,UpdateActivity.class);
        MainActivity.this.startActivity(myIntent);
    }


}