package com.example.example;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;
public class InsertActivity extends AppCompatActivity {
    Button btnsave,btnview;
    EditText edtregno,edtname;
    ListView lststud;
    ArrayAdapter adpt;
    ArrayList sdata=new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        btnsave=(Button)findViewById(R.id.btnsave);
        edtregno=(EditText)findViewById(R.id.edtregno);
        edtname=(EditText)findViewById(R.id.edtname);
        btnview=(Button)findViewById(R.id.btnview);
        lststud=(ListView)findViewById(R.id.lststud);
    }
    public void Insert(View v){
        DatabaseAccessActivity ob=new DatabaseAccessActivity(InsertActivity.this);
        ob.Insertstud(edtregno.getText().toString(),edtname.getText().toString());
        Toast.makeText(getApplicationContext(),"Record Inserted Successfully",Toast.LENGTH_LONG).show();
    }
    public void ViewRecord(View v){
        DatabaseAccessActivity ob1=new DatabaseAccessActivity(InsertActivity.this);
        sdata=ob1.DisplayRecord();
        adpt=new ArrayAdapter(this,android.R.layout.simple_list_item_1,sdata);
        lststud.setAdapter(adpt);
    }

    public void MainMenu(View view) {
        Intent myIntent = new Intent(InsertActivity.this,MainActivity.class);
        InsertActivity.this.startActivity(myIntent);
    }
}

