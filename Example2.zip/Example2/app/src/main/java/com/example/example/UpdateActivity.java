package com.example.example;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import java.util.ArrayList;
public class UpdateActivity extends AppCompatActivity {

    Button btndisplay,btnupdate;
    EditText edtname,edtregno;
    ListView lststud;
    ArrayList studdata=new ArrayList();
    ArrayAdapter adpt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        btndisplay=(Button)findViewById(R.id.btndisplay);
        btnupdate=(Button)findViewById(R.id.btnupdate);
        edtname=(EditText)findViewById(R.id.edtname);
        edtregno=(EditText)findViewById(R.id.edtregno);
        lststud=(ListView)findViewById(R.id.lststud);
    }
    public void DisplayStud(View v){
        DatabaseAccessActivity ob=new DatabaseAccessActivity(UpdateActivity.this);
        studdata=ob.DisplayRecord();
        adpt=new ArrayAdapter(this,android.R.layout.simple_list_item_1,studdata);
        lststud.setAdapter(adpt);
    }
    public void UpdateStud(View v){
        DatabaseAccessActivity ob1=new DatabaseAccessActivity(UpdateActivity.this);
        ob1.UpdateRecord(edtregno.getText().toString(),edtname.getText().toString());
        Toast.makeText(getApplicationContext(),"Record successfully updated",Toast.LENGTH_LONG).show();

    }

    public void mainMenu(View view) {
        Intent myIntent = new Intent(UpdateActivity.this,MainActivity.class);
       UpdateActivity.this.startActivity(myIntent);
    }
}

